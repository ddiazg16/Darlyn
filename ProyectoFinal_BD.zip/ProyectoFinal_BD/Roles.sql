-- Consulta para Req 5: Evidenciar permisos de los roles
SELECT 
    dp.permission_name,
    dp.state_desc,
    OBJECT_NAME(dp.major_id) AS Objeto,
    USER_NAME(dp.grantee_principal_id) AS Rol_o_Usuario
FROM 
    sys.database_permissions dp
WHERE 
    USER_NAME(dp.grantee_principal_id) IN ('AppReader', 'AppWriter', 'AuditorDB')
ORDER BY 
    Rol_o_Usuario, dp.permission_name;
