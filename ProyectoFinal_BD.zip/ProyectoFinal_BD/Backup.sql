-- 8.1 BACKUP FULL (Completo)
BACKUP DATABASE Academia2022
TO DISK = 'C:\SQLBackups\Academia2022_FULL.bak' -- <-- �VERIFICA ESTA RUTA!
WITH INIT, -- Sobrescribe cualquier backup existente en el archivo
NAME = 'Backup Completo Inicial';

-- Simulaci�n de una transacci�n (Ejemplo: Insertar una nueva carrera)
INSERT INTO Academico.Carreras (CarreraNombre) VALUES ('Marketing Digital');

-- 8.2 BACKUP DIFFERENTIAL (Diferencial)
BACKUP DATABASE Academia2022
TO DISK = 'C:\SQLBackups\Academia2022_DIFF.bak' -- <-- �VERIFICA ESTA RUTA!
WITH DIFFERENTIAL, -- Indica que solo se guarden los cambios desde el �ltimo FULL
NAME = 'Backup Diferencial de Cambios';

-- Consulta para verificar los backups en el historial del sistema (msdb)
SELECT 
    database_name, 
    CASE backup_type 
        WHEN 1 THEN 'FULL' 
        WHEN 5 THEN 'DIFFERENTIAL' 
        ELSE 'OTRO' 
    END AS TipoBackup,
    backup_start_date, 
    physical_device_name
FROM 
    msdb.dbo.backupset bs
INNER JOIN 
    msdb.dbo.backupmediafamily bmf ON bs.media_set_id = bmf.media_set_id
WHERE 
    database_name = 'Academia2022'
ORDER BY 
    backup_start_date DESC;
