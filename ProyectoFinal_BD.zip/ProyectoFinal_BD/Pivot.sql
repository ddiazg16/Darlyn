-- Consulta para Req 2: Uso de Funci�n de Ventana (Carga Acad�mica)
SELECT
    a.NombreCompleto,
    m.MatriculaPeriodo,
    COUNT(*) AS CursosInscritos,
    -- ROW_NUMBER() asigna un n�mero de fila �nico dentro de cada partici�n (Periodo)
    ROW_NUMBER() OVER(PARTITION BY m.MatriculaPeriodo ORDER BY COUNT(*) DESC) AS RankingCarga
FROM
    Academico.Matriculas m
JOIN
    Academico.Alumnos a ON m.AlumnoID = a.AlumnoID
GROUP BY
    a.NombreCompleto, m.MatriculaPeriodo
ORDER BY
    m.MatriculaPeriodo, RankingCarga;
