-- Consulta para Req 3 (Buscar por Apellido, que no es el �ndice principal)
SELECT AlumnoNombre, AlumnoApellido, AlumnoEdad 
FROM Academico.Alumnos 
WHERE AlumnoApellido = 'Lopez';
CREATE NONCLUSTERED INDEX IX_Alumnos_Apellido ON Academico.Alumnos(AlumnoApellido);